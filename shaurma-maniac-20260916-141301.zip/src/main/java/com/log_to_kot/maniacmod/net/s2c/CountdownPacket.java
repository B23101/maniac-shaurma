package com.log_to_kot.maniacmod.net.s2c;

import com.log_to_kot.maniacmod.net.ModPacket;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Сервер → клієнт: цифра відліку (shaurma-lib AnimatedCountdownSystem).
 *
 * Використовується технічними фазами: відлік до кінця кінематографа,
 * до старту полювання, до закриття воріт.
 *
 * @param digit      число, що показується; 0 = сховати
 * @param accentArgb колір акценту (наприклад червоний у фіналі)
 */
public record CountdownPacket(int digit, int accentArgb) implements ModPacket {

    public CountdownPacket(FriendlyByteBuf buf) {
        this(buf.readVarInt(), buf.readInt());
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(digit);
        buf.writeInt(accentArgb);
    }

    @Override
    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
            com.log_to_kot.maniacmod.client.ClientPacketHandler.onCountdown(digit, accentArgb));
    }
}
