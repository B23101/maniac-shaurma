package com.log_to_kot.maniacmod.net.s2c;

import com.log_to_kot.maniacmod.map.zones.GeneratorPoi;
import com.log_to_kot.maniacmod.net.ModPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Сервер → клієнт: підсвітка генераторів (клавіша 5 у виживого).
 *
 * Надсилається ОДИН раз на активацію зі списком усіх генераторів та
 * їхніми станами; клієнт сам гасить підсвітку через durationTicks.
 * Це навмисно: тримати підсвітку щотіковим потоком пакетів на 300×300
 * карті з десятком генераторів — марний трафік.
 *
 * Колір рахує сервер (GeneratorPoi.VisualState), щоб клієнт не міг
 * показати стан, якого насправді немає.
 *
 * @param durationTicks скільки тіків тримати підсвітку
 * @param entries       генератори та їхні стани
 */
public record GeneratorHighlightPacket(int durationTicks, List<Entry> entries) implements ModPacket {

    public record Entry(BlockPos pos, GeneratorPoi.VisualState state) {}

    public GeneratorHighlightPacket(FriendlyByteBuf buf) {
        this(buf.readVarInt(), readEntries(buf));
    }

    private static List<Entry> readEntries(FriendlyByteBuf buf) {
        int size = buf.readVarInt();
        List<Entry> list = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            list.add(new Entry(buf.readBlockPos(), buf.readEnum(GeneratorPoi.VisualState.class)));
        }
        return list;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(durationTicks);
        buf.writeVarInt(entries.size());
        for (Entry e : entries) {
            buf.writeBlockPos(e.pos());
            buf.writeEnum(e.state());
        }
    }

    @Override
    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
            com.log_to_kot.maniacmod.client.ClientPacketHandler
                .onGeneratorHighlight(durationTicks, entries));
    }
}
