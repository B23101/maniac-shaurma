package com.log_to_kot.maniacmod.net.s2c;

import com.log_to_kot.maniacmod.net.ModPacket;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Сервер → клієнт: прогрес генератора, який гравець зараз ремонтує.
 *
 * v3-еквівалент: однойменний пакет, але без стадії заливу бензину —
 * тепер одним пакетом передаються обидві стадії дизайну.
 *
 * @param visible      false = сховати бар (гравець відпустив ПКМ)
 * @param stage        0 = ремонт, 1 = бензин
 * @param stagePercent прогрес поточної міні-гри / заливу, 0–100
 * @param minigamesDone скільки міні-ігор пройдено
 * @param minigamesTotal скільки треба всього
 * @param fuelPercent  залито бензину, 0–200
 */
public record GeneratorProgressPacket(boolean visible, int stage, int stagePercent,
                                       int minigamesDone, int minigamesTotal,
                                       int fuelPercent) implements ModPacket {

    /** Сховати бар. */
    public static GeneratorProgressPacket hidden() {
        return new GeneratorProgressPacket(false, 0, 0, 0, 0, 0);
    }

    public GeneratorProgressPacket(FriendlyByteBuf buf) {
        this(buf.readBoolean(), buf.readVarInt(), buf.readVarInt(),
             buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(visible);
        buf.writeVarInt(stage);
        buf.writeVarInt(stagePercent);
        buf.writeVarInt(minigamesDone);
        buf.writeVarInt(minigamesTotal);
        buf.writeVarInt(fuelPercent);
    }

    @Override
    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
            com.log_to_kot.maniacmod.client.ClientPacketHandler.onGeneratorProgress(this));
    }
}
