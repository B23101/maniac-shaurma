package com.log_to_kot.maniacmod.net.s2c;

import com.log_to_kot.maniacmod.net.ModPacket;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Сервер → клієнт: роль локального гравця в цьому матчі.
 *
 * Надсилається на фазі ROLE_REVEAL і повторно при вході гравця в гру
 * (реконект), щоб клієнт не лишився з порожньою роллю.
 *
 * v3-еквівалент: ManiacTypePacket, який передавав лише тип маньяка й
 * нічого не казав виживим — тому клієнт виживого взагалі не знав, що
 * він у грі.
 *
 * @param role        роль локального гравця
 * @param archetypeId id архетипу: маньяка ("chucky") або ролі виживого
 *                    ("default"); порожній рядок для глядача
 */
public record RoleSyncPacket(Role role, String archetypeId) implements ModPacket {

    public enum Role { MANIAC, SURVIVOR, SPECTATOR }

    public RoleSyncPacket(FriendlyByteBuf buf) {
        this(buf.readEnum(Role.class), buf.readUtf());
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeEnum(role);
        buf.writeUtf(archetypeId);
    }

    @Override
    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
            com.log_to_kot.maniacmod.client.ClientPacketHandler.onRole(role, archetypeId));
    }
}
