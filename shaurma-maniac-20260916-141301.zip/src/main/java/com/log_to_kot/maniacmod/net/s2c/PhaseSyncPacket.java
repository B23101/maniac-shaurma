package com.log_to_kot.maniacmod.net.s2c;

import com.log_to_kot.maniacmod.core.phase.GamePhase;
import com.log_to_kot.maniacmod.net.ModPacket;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Сервер → клієнт: поточна фаза матчу.
 *
 * Найважливіший пакет клієнта. Завдяки йому клієнтський код (HUD,
 * клавіші, оверлеї) питає фазу локально, не смикаючи сервер і не
 * тримаючи власних прапорців «гра йде».
 *
 * У v3 цього пакета не було взагалі: клієнт здогадувався про стан гри
 * за побічними ознаками (чи прийшов ManiacTypePacket, чи показаний
 * overlay), тому після реконекту HUD показував дурниці.
 */
public record PhaseSyncPacket(GamePhase phase) implements ModPacket {

    public PhaseSyncPacket(FriendlyByteBuf buf) {
        this(buf.readEnum(GamePhase.class));
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeEnum(phase);
    }

    @Override
    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
            com.log_to_kot.maniacmod.client.ClientPacketHandler.onPhase(phase));
    }
}
