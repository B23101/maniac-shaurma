package com.log_to_kot.maniacmod.net.s2c;

import com.log_to_kot.maniacmod.net.ModPacket;
import dev.shaurmalib.common.overlay.ActionBarMessageType;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Сервер → клієнт: повідомлення в actionbar через
 * shaurma-lib ActionBarMessageSystem.
 *
 * Замінює десятки викликів {@code sendSystemMessage("§c...")} з v3:
 * там кожне повідомлення несло кольорові коди прямо в рядку, тому
 * змінити стиль означало правити рядки по всьому моду.
 *
 * @param translationKey ключ локалізації, не готовий текст — інакше
 *                       мова прив'язана до сервера, а не до клієнта
 * @param args           аргументи підстановки
 */
public record ActionBarPacket(ActionBarMessageType type, String translationKey,
                               String[] args) implements ModPacket {

    public ActionBarPacket(ActionBarMessageType type, String translationKey) {
        this(type, translationKey, new String[0]);
    }

    public ActionBarPacket(FriendlyByteBuf buf) {
        this(buf.readEnum(ActionBarMessageType.class), buf.readUtf(), readArgs(buf));
    }

    private static String[] readArgs(FriendlyByteBuf buf) {
        String[] out = new String[buf.readVarInt()];
        for (int i = 0; i < out.length; i++) out[i] = buf.readUtf();
        return out;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeEnum(type);
        buf.writeUtf(translationKey);
        buf.writeVarInt(args.length);
        for (String arg : args) buf.writeUtf(arg);
    }

    @Override
    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
            com.log_to_kot.maniacmod.client.ClientPacketHandler
                .onActionBar(type, translationKey, args));
    }
}
