package com.log_to_kot.maniacmod.net.s2c;

import com.log_to_kot.maniacmod.net.ModPacket;
import com.log_to_kot.maniacmod.survivors.SurvivorState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Сервер → клієнт: показники виживого для HUD.
 *
 * ОДИН пакет на всі показники замість трьох окремих. Хп, стаміна й
 * стан змінюються разом і малюються разом — надсилати їх різними
 * пакетами означало б три рази на тік слати по кілька байтів і
 * ризикувати, що HUD покаже хп з одного тіку, а стан з іншого.
 *
 * Надсилається лише коли значення реально змінились, не щотік.
 *
 * @param hp            поточне здоров'я
 * @param maxHp         максимум (100 у звичайного виживого)
 * @param stamina       0.0–1.0
 * @param state         поточний стан (HEALTHY / BROKEN_LEG / ...)
 * @param heartbeat     0.0–1.0, наскільки близько маньяк (0 = не чути)
 */
public record SurvivorVitalsPacket(int hp, int maxHp, float stamina,
                                    SurvivorState state, float heartbeat) implements ModPacket {

    public SurvivorVitalsPacket(FriendlyByteBuf buf) {
        this(buf.readVarInt(), buf.readVarInt(), buf.readFloat(),
             buf.readEnum(SurvivorState.class), buf.readFloat());
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(hp);
        buf.writeVarInt(maxHp);
        buf.writeFloat(stamina);
        buf.writeEnum(state);
        buf.writeFloat(heartbeat);
    }

    @Override
    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
            com.log_to_kot.maniacmod.client.ClientPacketHandler
                .onVitals(hp, maxHp, stamina, state, heartbeat));
    }
}
