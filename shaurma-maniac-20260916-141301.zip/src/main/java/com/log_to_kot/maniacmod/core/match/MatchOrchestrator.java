package com.log_to_kot.maniacmod.core.match;

import com.log_to_kot.maniacmod.config.ConfigSchema;
import com.log_to_kot.maniacmod.config.ManiacConfigs;
import com.log_to_kot.maniacmod.core.phase.GamePhase;
import com.log_to_kot.maniacmod.core.phase.PhaseListener;
import com.log_to_kot.maniacmod.core.phase.PhaseManager;
import com.log_to_kot.maniacmod.core.phase.Phases;
import com.log_to_kot.maniacmod.map.GeneratorModule;
import com.log_to_kot.maniacmod.maniacs.ManiacArchetype;
import com.log_to_kot.maniacmod.maniacs.ManiacCombatModule;
import com.log_to_kot.maniacmod.spawn.SpawnPlanner;
import com.log_to_kot.maniacmod.spawn.SpawnPointKind;
import com.log_to_kot.maniacmod.survivors.SurvivorRegistry;
import dev.shaurmalib.common.lobby.LobbySpawnPoint;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Диригент матчу. Замінює РОЛЬ КООРДИНАТОРА старого
 * game/ManiacGameManager.java — але саме роль, а не весь клас.
 *
 * ── Що сюди НЕ переїхало навмисно ────────────────────────────────────
 * Старий ManiacGameManager на 898 рядків робив одночасно:
 *   координацію матчу, тік пасток, бій, трупи/воскресіння, ремонт
 *   генераторів, видачу предметів, ефекти маньяка, broadcast у чат.
 * Через це будь-яка правка пасток ризикувала зачепити бій — рівно
 * та проблема "один кусок коду лізе в інший", з якої почалась
 * реорганізація.
 *
 * Тут лишається ЛИШЕ координація:
 *   хто маньяк, коли міняється фаза, коли матч закінчено.
 * Решта живе у своїх модулях і підписується через PhaseListener:
 *   traps/      — тік і розміщення пасток
 *   survivors/  — хп, стаміна, стани, підняття непритомних
 *   map/zones/  — генератори, виходи, зони втечі
 *   items/      — ефекти предметів
 *   abilities/  — здібності маньяка
 *
 * ── Ланцюжок фаз ─────────────────────────────────────────────────────
 * LOBBY → CINEMATIC → SCATTER → ROLE_REVEAL → HUNT → POWERED
 *       → FINALE → ENDING → RESET → LOBBY
 * Кожен перехід — один виклик advanceTo(...); умови переходу описані
 * в методах нижче, а не розмазані по всьому моду.
 */
public final class MatchOrchestrator {

    private final PhaseManager phases = new PhaseManager();
    private final Random rng = new Random();
    private final SpawnPlanner spawnPlanner = new SpawnPlanner(rng);

    private MatchContext context = new MatchContext();

    /** Точка спавну лобі. Задається командою /maniac lobby set. */
    private volatile LobbySpawnPoint lobbySpawn = new LobbySpawnPoint(0, 64, 0, 0f);

    /** Модуль генераторів. Тримається полем, бо блок генератора звертається до нього напряму. */
    private final GeneratorModule generators = new GeneratorModule(() -> this);

    /** Удар маньяка. Тримається полем, бо хук AttackEntityEvent кличе його напряму. */
    private final ManiacCombatModule combat = new ManiacCombatModule(() -> this);

    public MatchOrchestrator() {
        Phases.bind(phases);
        // Синхронізація фази з клієнтами — теж звичайний модуль, а не
        // особливий випадок усередині PhaseManager. Реєструється
        // першим, щоб клієнт дізнався про фазу раніше, ніж модулі
        // почнуть слати свої пакети для цієї фази.
        phases.register(new PhaseNetworkSync());
        phases.register(generators);
        phases.register(combat);
    }

    /** Модуль генераторів — для GeneratorBlock і ServerPacketHandler. */
    public GeneratorModule generatorModule() {
        return generators;
    }

    /** Модуль удару — для хука AttackEntityEvent. */
    public ManiacCombatModule combat() {
        return combat;
    }

    /** Модуль, що розсилає фазу клієнтам. Нічого більше не робить. */
    private static final class PhaseNetworkSync implements PhaseListener {
        @Override public String id() { return "phase-sync"; }

        @Override
        public void onPhaseEnter(GamePhase phase, java.util.List<ServerPlayer> players) {
            com.log_to_kot.maniacmod.server.ServerHooks.broadcastPhase(players, phase);
        }
    }

    // ── Лобі (shaurma-lib LobbyModule читає це) ──────────────────────────

    /** Поточна точка лобі — передається у withLobby(...) як постачальник. */
    public LobbySpawnPoint currentLobbySpawn() {
        return lobbySpawn;
    }

    public void setLobbySpawn(double x, double y, double z, float yaw) {
        this.lobbySpawn = new LobbySpawnPoint(x, y, z, yaw);
    }

    // ── Доступ ───────────────────────────────────────────────────────────

    public PhaseManager phases()      { return phases; }
    public SpawnPlanner spawnPlanner() { return spawnPlanner; }

    // ── Фасад над MatchContext ───────────────────────────────────────────
    //
    // MatchContext сам по собі package-private (див. коментар у файлі
    // класу): жодного "дай мені весь контекст" ззовні пакету core.match.
    // Кожен метод нижче — це одна конкретна дія, яку модуль/пакет/пакет
    // мережі реально виконує. Немає методу під конкретну потребу — це
    // сигнал ДОДАТИ його тут, а не обходити фасад.
    //
    // Правило для нових методів: назва каже, ЩО робиться ("healSurvivor",
    // "assignedSpawnPoints"), а не "дай мені шматок стану, я розберусь".

    /** Чи цей гравець зараз маньяк цього матчу. */
    public boolean isManiac(UUID playerId) {
        return context.isManiac(playerId);
    }

    /** Чи цей гравець зараз виживий цього матчу. */
    public boolean isSurvivor(UUID playerId) {
        return context.isSurvivor(playerId);
    }

    /** Архетип поточного маньяка. null, якщо ще не обраний (фаза MENU). */
    public ManiacArchetype maniacArchetype() {
        return context.maniacArchetype();
    }

    /** Роль виживого за id. null, якщо гравець не виживий цього матчу. */
    public com.log_to_kot.maniacmod.survivors.SurvivorRole survivorRoleOf(UUID playerId) {
        return context.roleOf(playerId);
    }

    /** Поточний стан виживого (HEALTHY/BROKEN_LEG/CRAWLING/UNCONSCIOUS). */
    public com.log_to_kot.maniacmod.survivors.SurvivorState survivorStateOf(UUID playerId) {
        return context.stateOf(playerId);
    }

    /**
     * Лікує виживого. Повертає, скільки хп реально відновлено — 0,
     * якщо гравець не виживий або вже мав повне хп. Викликач (предмет)
     * саме за цим числом вирішує, чи витрачати себе.
     */
    public int healSurvivor(UUID playerId, int amount) {
        return context.heal(playerId, amount);
    }

    /** Знімає хп. true, якщо гравець щойно дійшов до 0. */
    public boolean damageSurvivor(UUID playerId, int amount) {
        return context.damage(playerId, amount);
    }

    /** Скільки виживих ще в матчі (не рахує втеклих і вибулих). */
    public int aliveSurvivorCount() {
        return context.aliveSurvivorCount();
    }

    /** Хто вже втік цього матчу. */
    public List<UUID> escapedSurvivorIds() {
        return context.escapedIds();
    }

    /** Досягнення матчу (POWER_RESTORED, EXIT_OPENED...) — лише читання. */
    public java.util.Set<MatchObjectives.Objective> completedObjectives() {
        return context.objectives().completed();
    }

    /** Позначає ціль матчу досягнутою. Викликають лише зони/генератори. */
    public void completeObjective(MatchObjectives.Objective objective) {
        context.objectives().complete(objective);
    }

    /** Генератор за позицією. null, якщо на цій позиції генератора немає. */
    public com.log_to_kot.maniacmod.map.zones.GeneratorPoi generatorAt(
            net.minecraft.core.BlockPos pos) {
        for (var g : generators()) {
            if (g.pos().equals(pos)) return g;
        }
        return null;
    }

    /** Усі генератори карти — лише для читання (статус, підрахунок). */
    public List<com.log_to_kot.maniacmod.map.zones.GeneratorPoi> generators() {
        return context.map().generators();
    }

    /** Розмітка точок цього матчу — лише для читання (команди, план спавну). */
    public List<com.log_to_kot.maniacmod.spawn.SpawnPoint> spawnPoints() {
        return context.spawnPoints();
    }

    /** Додає точку розмітки (команда /maniac point add). */
    public void addSpawnPoint(com.log_to_kot.maniacmod.spawn.SpawnPoint point) {
        context.addSpawnPoint(point);
    }

    /** Стирає всю розмітку карти (команда /maniac point clear). */
    public void clearMap() {
        context.spawnPoints().clear();
        context.map().clear();
    }

    /** Рядок статусу для /maniac status — єдине місце, що читає кілька полів разом. */
    public String debugStatusLine() {
        return "виживих: " + context.aliveSurvivorCount()
            + " | втекло: " + context.escapedIds().size()
            + " | точок: " + context.spawnPoints().size()
            + " | досягнення: " + context.objectives().completed();
    }

    /** Модулі реєструють свої PhaseListener тут, зазвичай на старті сервера. */
    public void registerModule(PhaseListener listener) {
        phases.register(listener);
    }

    /**
     * Міст до shaurma-lib. v3-еквівалент: ManiacGameManager.attachLifecycle().
     * Тепер бібліотека отримує стан із фаз, а не з окремого enum GameState —
     * тобто дзеркалення живе в одному місці й не може розійтися з реальністю.
     */
    public void attachLifecycle(PhaseManager.LifecycleSink sink) {
        phases.attachLifecycleSink(sink);
    }

    // ── Запуск матчу ─────────────────────────────────────────────────────

    /**
     * Старт. Створює НОВИЙ MatchContext — тому жодного ручного
     * очищення двадцяти списків, як було в resetGame().
     *
     * Порядок навмисний: спершу перевіряємо, що план розкидання
     * взагалі можливий (SpawnPlanner кидає SpawnPlanFailure), і лише
     * потім змінюємо фазу. Якщо карта розмічена погано — гравці
     * лишаються в лобі, а не зависають у напівстарті.
     */
    public boolean start(List<ServerPlayer> players, ServerPlayer maniacPlayer,
                         ManiacArchetype maniacArchetype) {
        if (!phases.is(GamePhase.LOBBY)) return false;
        if (players.size() < ManiacConfigs.get(ConfigSchema.MIN_PLAYERS)) return false;

        MatchContext fresh = new MatchContext();
        fresh.assignManiac(maniacPlayer.getUUID(), maniacArchetype);

        List<UUID> survivorIds = new ArrayList<>();
        for (ServerPlayer p : players) {
            if (p.getUUID().equals(maniacPlayer.getUUID())) continue;
            fresh.addSurvivor(p.getUUID(), SurvivorRegistry.defaultRole());
            survivorIds.add(p.getUUID());
        }

        // TODO(міграція): підвантажити розмітку точок світу у fresh
        //                 перед плануванням (див. spawn/README.md).

        // Перевірка розмітки ДО зміни фази: якщо точок менше, ніж гравців,
        // краще сказати це в лобі, ніж посеред розкидання.
        int survivorPoints = SpawnPlanner
            .countByKind(fresh.spawnPoints())
            .getOrDefault(SpawnPointKind.SURVIVOR, 0);
        if (!fresh.spawnPoints().isEmpty() && survivorPoints < survivorIds.size()) {
            return false;
        }

        this.context = fresh;

        advanceTo(GamePhase.CINEMATIC, players);
        return true;
    }

    // ── Переходи ─────────────────────────────────────────────────────────

    public void advanceTo(GamePhase next, List<ServerPlayer> players) {
        phases.transitionTo(next, players);
    }

    /**
     * Один серверний тік. ServerEventHandler викликає ЦЕ і більше
     * нічого — без власних перевірок фази.
     *
     * v3-еквівалент: у ServerEventHandler.onServerTick() стояв рядок
     *   if (getGameState() != RUNNING) return;
     * а далі шість ручних викликів tickBearTraps/tickWires/tickRope/...
     * Кожна нова механіка означала ще один рядок саме там. Тепер
     * модуль сам вирішує, чи йому тікати, через свій PhaseListener.
     */
    public void tick(List<ServerPlayer> players) {
        context.tick();
        phases.tick(players);
        checkPhaseExitConditions(players);
    }

    /**
     * Єдине місце, де вирішується "чи пора далі".
     *
     * ── Переходи йдуть від ДІЙ, а не від кількості гравців ───────────
     * HUNT → POWERED: подано живлення (генератори доведені до кінця).
     * POWERED → FINALE: відкрито вихід.
     * Будь-яка ігрова фаза → ENDING: виживих не лишилось узагалі.
     *
     * Кількість гравців ніде не є умовою ПРОГРЕСУ. «Лишився один
     * виживий» — не досягнення команди: решта могла вийти з гри або
     * впасти з даху, і фінал у такому матчі нічого не означає.
     * Єдине місце, де рахуються люди, — умова завершення, і це вже
     * не прогрес.
     */
    private void checkPhaseExitConditions(List<ServerPlayer> players) {
        if (!phases.isGameplay()) return;

        if (noSurvivorsLeft()) {
            advanceTo(GamePhase.ENDING, players);
            return;
        }

        MatchObjectives objectives = context.objectives();

        switch (phases.current()) {
            case HUNT -> {
                if (allRequiredGeneratorsDone()) {
                    objectives.complete(MatchObjectives.Objective.POWER_RESTORED);
                    advanceTo(GamePhase.POWERED, players);
                }
            }
            case POWERED -> {
                if (objectives.isComplete(MatchObjectives.Objective.EXIT_OPENED)) {
                    advanceTo(GamePhase.FINALE, players);
                }
            }
            default -> { /* FINALE завершується лише через noSurvivorsLeft */ }
        }
    }

    /**
     * Готово стільки генераторів, скільки вимагає конфіг. Не «усі, що
     * є на карті»: генераторів може бути розмічено більше, ніж треба —
     * це нормальний дизайн, коли команда обирає, які саме лагодити.
     */
    private boolean allRequiredGeneratorsDone() {
        int required = ManiacConfigs.get(ConfigSchema.GENERATORS_REQUIRED);
        long done = generators().stream()
            .filter(g -> g.isCompleted())
            .count();
        return done >= required;
    }

    private boolean noSurvivorsLeft() {
        return context.aliveSurvivorCount() == 0;
    }

    // ── Завершення ───────────────────────────────────────────────────────

    /**
     * Гравець вийшов. Маньяк, що вийшов, завершує матч — інакше
     * виживі бігали б порожньою картою (у v3 матч просто зависав).
     */
    public void onPlayerLeft(ServerPlayer player) {
        if (!phases.isGameplay()) return;

        List<ServerPlayer> online = player.getServer().getPlayerList().getPlayers();
        if (context.isManiac(player.getUUID())) {
            advanceTo(GamePhase.ENDING, online);
            return;
        }
        context.removeSurvivor(player.getUUID());
    }

    /**
     * Маньяк обрав персонажа в меню. Викликається з
     * ServerPacketHandler після перевірки id у реєстрі.
     */
    public void onManiacChosen(ServerPlayer player, ManiacArchetype archetype) {
        if (!phases.is(GamePhase.ROLE_REVEAL) && !phases.is(GamePhase.LOBBY)) return;
        if (!context.isManiac(player.getUUID())) return;

        context.assignManiac(player.getUUID(), archetype);
    }

    public void reset(List<ServerPlayer> players) {
        advanceTo(GamePhase.RESET, players);
        this.context = new MatchContext();
        advanceTo(GamePhase.LOBBY, players);
    }

    /** Зупинка сервера — знімаємо статичне посилання, щоб не текло. */
    public void shutdown() {
        Phases.unbind();
    }
}
